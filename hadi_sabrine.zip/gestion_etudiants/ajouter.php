<?php
require_once 'functions.php';
exiger_connexion();

$etudiants = lire_etudiants();
$id = (int)($_GET['id'] ?? 0);
$modif = $id > 0;

if ($modif && !isset($etudiants[$id])) {
    flash_set('Étudiant introuvable.', 'erreur');
    header('Location: liste.php');
    exit;
}

$valeurs = $modif
    ? $etudiants[$id]
    : ['nom' => '', 'prenom' => '', 'filiere' => '', 'note' => '', 'photo' => ''];
$erreurs = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = nettoyer($_POST['nom'] ?? '');
    $prenom = nettoyer($_POST['prenom'] ?? '');
    $filiere = $_POST['filiere'] ?? '';
    $note = str_replace(',', '.', nettoyer($_POST['note'] ?? ''));

    // On garde les valeurs saisies pour réafficher le formulaire
    $valeurs = array_merge($valeurs, ['nom' => $nom, 'prenom' => $prenom, 'filiere' => $filiere, 'note' => $note]);

    if ($nom === '') {
        $erreurs[] = 'Le nom est obligatoire.';
    }
    if ($prenom === '') {
        $erreurs[] = 'Le prénom est obligatoire.';
    }
    if (!in_array($filiere, FILIERES, true)) {
        $erreurs[] = 'Filière invalide.';
    }
    if ($note === '' || !is_numeric($note)) {
        $erreurs[] = 'La note doit être un nombre.';
    } elseif ((float)$note < 0 || (float)$note > 20) {
        $erreurs[] = 'La note doit être comprise entre 0 et 20.';
    }

    // Bonus : refuser un doublon nom + prénom
    if ($nom !== '' && $prenom !== '') {
        foreach ($etudiants as $e) {
            if ($e['id'] !== $id
                && strcasecmp($e['nom'], $nom) === 0
                && strcasecmp($e['prenom'], $prenom) === 0) {
                $erreurs[] = 'Cet étudiant existe déjà.';
                break;
            }
        }
    }

    // Photo (facultative)
    $photoEnvoyee = photo_envoyee($_FILES['photo'] ?? []);
    if ($photoEnvoyee) {
        $e = erreur_photo($_FILES['photo']);
        if ($e !== null) {
            $erreurs[] = $e;
        }
    }

    if (empty($erreurs)) {
        $photo = $modif ? $etudiants[$id]['photo'] : '';
        if ($photoEnvoyee) {
            $nouvelle = deplacer_photo($_FILES['photo']);
            if ($nouvelle === '') {
                $erreurs[] = "Impossible d'enregistrer la photo.";
            } else {
                if ($modif) {
                    supprimer_photo($photo);   // supprime l'ancienne
                }
                $photo = $nouvelle;
            }
        }
    }

    if (empty($erreurs)) {
        if (!$modif) {
            $id = $etudiants ? max(array_keys($etudiants)) + 1 : 1;
        }
        $etudiants[$id] = [
            'id'      => $id,
            'nom'     => mb_strtolower($nom, 'UTF-8'),
            'prenom'  => mb_strtolower($prenom, 'UTF-8'),
            'filiere' => $filiere,
            'note'    => (float)$note,
            'photo'   => $photo,
        ];
        sauver_etudiants($etudiants);
        flash_set($modif ? 'Étudiant modifié avec succès.' : 'Étudiant ajouté avec succès.');
        header('Location: liste.php');
        exit;
    }
}

$titre = $modif ? "Modifier l'étudiant" : 'Ajouter un étudiant';
include 'header.php';
?>

<?php if ($erreurs): ?>
    <div class="message erreur">
        <ul>
            <?php foreach ($erreurs as $err): ?>
                <li><?= h($err) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" class="carte">
    <label for="nom">Nom</label>
    <input type="text" id="nom" name="nom" value="<?= h((string)$valeurs['nom']) ?>">

    <label for="prenom">Prénom</label>
    <input type="text" id="prenom" name="prenom" value="<?= h((string)$valeurs['prenom']) ?>">

    <label for="filiere">Filière</label>
    <select id="filiere" name="filiere">
        <option value="">-- Choisir --</option>
        <?php foreach (FILIERES as $f): ?>
            <option value="<?= h($f) ?>" <?= $valeurs['filiere'] === $f ? 'selected' : '' ?>><?= h($f) ?></option>
        <?php endforeach; ?>
    </select>

    <label for="note">Note (0 à 20)</label>
    <input type="text" id="note" name="note" value="<?= h((string)$valeurs['note']) ?>">

    <label for="photo">Photo (jpg, jpeg, png – 1 Mo max, facultative)</label>
    <?php if ($modif && $valeurs['photo'] !== '' && file_exists(DOSSIER_PHOTOS . basename($valeurs['photo']))): ?>
        <img class="photo" src="uploads/<?= h(basename($valeurs['photo'])) ?>" alt="Photo actuelle">
    <?php endif; ?>
    <input type="file" id="photo" name="photo" accept=".jpg,.jpeg,.png">

    <button type="submit"><?= $modif ? 'Enregistrer' : 'Ajouter' ?></button>
    <a href="liste.php">Annuler</a>
</form>

<?php include 'footer.php'; ?>
