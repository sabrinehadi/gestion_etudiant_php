<?php
// Bonus : export CSV de la liste
require_once 'functions.php';
exiger_connexion();

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="etudiants.csv"');

$sortie = fopen('php://output', 'w');
fwrite($sortie, "\xEF\xBB\xBF"); // BOM pour qu'Excel lise bien les accents
fputcsv($sortie, ['id', 'nom', 'prenom', 'filiere', 'note'], ';');
foreach (lire_etudiants() as $e) {
    fputcsv($sortie, [$e['id'], $e['nom'], $e['prenom'], $e['filiere'], $e['note']], ';');
}
fclose($sortie);
