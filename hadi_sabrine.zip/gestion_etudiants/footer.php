</main>
<footer class="pied">
    <p>TP PHP – Gestion des étudiants – <?= date('d/m/Y') ?></p>
</footer>
<script src="script.js"></script>
</body>
</html>
