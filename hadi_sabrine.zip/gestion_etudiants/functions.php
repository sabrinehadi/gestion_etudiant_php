<?php
// ===== Exercice 2 : fichiers communs =====
session_start();

const FICHIER = __DIR__ . '/data/etudiants.txt';
const DOSSIER_PHOTOS = __DIR__ . '/uploads/';
const FILIERES = ['GI', 'IDIA', 'GE', 'GC'];
const UTILISATEURS = [
    'admin' => '1234',
    'prof'  => 'prof2026',
];
const EXTENSIONS_PHOTO = ['jpg', 'jpeg', 'png'];
const TAILLE_MAX_PHOTO = 1048576; // 1 Mo

// Bonus : cookie "theme" (clair / sombre) choisi via ?theme=...
if (isset($_GET['theme']) && in_array($_GET['theme'], ['clair', 'sombre'], true)) {
    setcookie('theme', $_GET['theme'], time() + 30 * 24 * 3600, '/');
    $_COOKIE['theme'] = $_GET['theme'];
}

// Protège l'affichage (XSS)
function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function connecte(): bool
{
    return isset($_SESSION['login']);
}

function exiger_connexion(): void
{
    if (!connecte()) {
        header('Location: index.php');
        exit;
    }
}

// ===== Exercice 3 : lecture / écriture du fichier texte =====

// Retourne un tableau associatif indexé par l'id
function lire_etudiants(): array
{
    if (!file_exists(FICHIER)) {
        return [];
    }
    $lignes = file(FICHIER, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $liste = [];
    foreach ($lignes as $ligne) {
        $p = explode(';', $ligne);
        if (count($p) < 5) {
            continue; // ligne invalide
        }
        $id = (int)$p[0];
        $liste[$id] = [
            'id'      => $id,
            'nom'     => $p[1],
            'prenom'  => $p[2],
            'filiere' => $p[3],
            'note'    => (float)$p[4],
            'photo'   => $p[5] ?? '',
        ];
    }
    return $liste;
}

function sauver_etudiants(array $liste): void
{
    $lignes = [];
    foreach ($liste as $e) {
        $lignes[] = implode(';', [$e['id'], $e['nom'], $e['prenom'], $e['filiere'], $e['note'], $e['photo']]);
    }
    $contenu = $lignes ? implode(PHP_EOL, $lignes) . PHP_EOL : '';
    file_put_contents(FICHIER, $contenu, LOCK_EX);
}

// Supprime espaces inutiles, ';' et retours à la ligne
function nettoyer(string $s): string
{
    $s = str_replace([';', "\r", "\n"], ' ', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return trim($s);
}

// ===== Affichage =====
function nom_affiche(string $nom): string
{
    return mb_strtoupper($nom, 'UTF-8');
}

function prenom_affiche(string $prenom): string
{
    // équivalent de ucfirst compatible avec les accents
    return mb_strtoupper(mb_substr($prenom, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($prenom, 1, null, 'UTF-8');
}

// ===== Messages flash =====
function flash_set(string $message, string $type = 'succes'): void
{
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}

function flash_get(): ?array
{
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

// ===== Exercice 9 : photo =====

// Retourne true si un fichier a été choisi
function photo_envoyee(array $f): bool
{
    return ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
}

// Retourne un message d'erreur, ou null si la photo est valide
function erreur_photo(array $f): ?string
{
    if ($f['error'] !== UPLOAD_ERR_OK) {
        if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE) {
            return 'La photo est trop volumineuse (1 Mo maximum).';
        }
        return "Erreur lors de l'envoi de la photo (code " . $f['error'] . ').';
    }
    if ($f['size'] > TAILLE_MAX_PHOTO) {
        return 'La photo est trop volumineuse (1 Mo maximum).';
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, EXTENSIONS_PHOTO, true)) {
        return 'Format de photo non autorisé (jpg, jpeg ou png).';
    }
    if (@getimagesize($f['tmp_name']) === false) {
        return "Le fichier envoyé n'est pas une image valide.";
    }
    return null;
}

// Renomme avec uniqid() et déplace dans uploads/ ; retourne le nouveau nom ('' si échec)
function deplacer_photo(array $f): string
{
    if (!is_dir(DOSSIER_PHOTOS)) {
        mkdir(DOSSIER_PHOTOS, 0775, true);
    }
    $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    $nom = uniqid('etu_') . '.' . $ext;
    return move_uploaded_file($f['tmp_name'], DOSSIER_PHOTOS . $nom) ? $nom : '';
}

function supprimer_photo(string $photo): void
{
    if ($photo !== '') {
        $chemin = DOSSIER_PHOTOS . basename($photo);
        if (file_exists($chemin)) {
            unlink($chemin);
        }
    }
}
