<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($titre ?? 'Gestion des étudiants') ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<?php $theme = ($_COOKIE['theme'] ?? 'clair') === 'sombre' ? 'sombre' : 'clair'; ?>
<body class="<?= $theme ?>">
<header class="entete">
    <div class="entete-contenu">
        <h1>Gestion des étudiants</h1>
        <?php if (connecte()): ?>
            <nav>
                <a href="liste.php">Liste</a>
                <a href="ajouter.php">Ajouter</a>
                <a href="export.php">Export CSV</a>
                <?php $autre = $theme === 'sombre' ? 'clair' : 'sombre'; ?>
                <a href="?<?= h(http_build_query(array_merge($_GET, ['theme' => $autre]))) ?>">Thème <?= $autre ?></a>
                <a href="logout.php">Déconnexion (<?= h($_SESSION['login']) ?>)</a>
            </nav>
        <?php endif; ?>
    </div>
</header>
<main class="contenu">
    <h2><?= h($titre ?? '') ?></h2>
