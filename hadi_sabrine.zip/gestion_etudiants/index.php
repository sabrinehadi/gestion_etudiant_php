<?php
require_once 'functions.php';

// Déjà connecté : direction la liste
if (connecte()) {
    header('Location: liste.php');
    exit;
}

$erreur = '';
$login = $_COOKIE['dernier_user'] ?? '';   // pré-remplissage (cookie)

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $mdp = $_POST['mdp'] ?? '';

    if (isset(UTILISATEURS[$login]) && hash_equals(UTILISATEURS[$login], $mdp)) {
        session_regenerate_id(true);
        $_SESSION['login'] = $login;
        setcookie('dernier_user', $login, time() + 7 * 24 * 3600, '/');
        header('Location: liste.php');
        exit;
    }
    $erreur = 'Login ou mot de passe incorrect.';
}

$titre = 'Connexion';
include 'header.php';
?>

<?php if ($erreur !== ''): ?>
    <p class="message erreur"><?= h($erreur) ?></p>
<?php endif; ?>

<form method="post" class="carte">
    <label for="login">Login</label>
    <input type="text" id="login" name="login" value="<?= h($login) ?>" required>

    <label for="mdp">Mot de passe</label>
    <input type="password" id="mdp" name="mdp" required>

    <button type="submit">Se connecter</button>
</form>

<?php include 'footer.php'; ?>
