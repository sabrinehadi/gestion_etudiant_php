<?php
require_once 'functions.php';
exiger_connexion();

$titre = 'Liste des étudiants';
$flash = flash_get();   // lu puis supprimé de la session

// --- Recherche et tri (GET) ---
$q = trim($_GET['q'] ?? '');
$tri = $_GET['tri'] ?? 'ajout';
$tris = [
    'ajout'   => "Ordre d'ajout",
    'nom'     => 'Nom',
    'filiere' => 'Filière',
    'note'    => 'Note décroissante',
];
if (!array_key_exists($tri, $tris)) {
    $tri = 'ajout';
}

$etudiants = lire_etudiants();

if ($q !== '') {
    $etudiants = array_filter($etudiants, function ($e) use ($q) {
        return mb_stripos($e['nom'], $q) !== false || mb_stripos($e['prenom'], $q) !== false;
    });
}

if ($tri === 'nom') {
    usort($etudiants, fn($a, $b) => strcasecmp($a['nom'], $b['nom']));
} elseif ($tri === 'filiere') {
    usort($etudiants, fn($a, $b) => strcasecmp($a['filiere'], $b['filiere']));
} elseif ($tri === 'note') {
    usort($etudiants, fn($a, $b) => $b['note'] <=> $a['note']);
}

// --- Statistiques (sans division par zéro) ---
$nb = count($etudiants);
$notes = array_column($etudiants, 'note');
$moyenne = $nb > 0 ? array_sum($notes) / $nb : 0;
$meilleure = $nb > 0 ? max($notes) : null;

// Bonus : moyenne par filière
$parFiliere = [];
foreach ($etudiants as $e) {
    $parFiliere[$e['filiere']][] = $e['note'];
}
ksort($parFiliere);

include 'header.php';
?>

<?php if ($flash): ?>
    <p class="message <?= h($flash['type']) ?>"><?= h($flash['message']) ?></p>
<?php endif; ?>

<form method="get" class="recherche">
    <input type="text" id="q" name="q" placeholder="Rechercher un nom ou prénom..." value="<?= h($q) ?>">
    <select name="tri">
        <?php foreach ($tris as $cle => $libelle): ?>
            <option value="<?= h($cle) ?>" <?= $tri === $cle ? 'selected' : '' ?>><?= h($libelle) ?></option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Valider</button>
</form>

<div class="stats">
    <span><strong><?= $nb ?></strong> étudiant(s) affiché(s)</span>
    <span>Moyenne : <strong><?= $nb > 0 ? number_format($moyenne, 2, ',', ' ') : '-' ?></strong></span>
    <span>Meilleure note : <strong><?= $meilleure !== null ? number_format($meilleure, 2, ',', ' ') : '-' ?></strong></span>
</div>

<?php if ($parFiliere): ?>
    <p class="par-filiere">Moyenne par filière :
        <?php foreach ($parFiliere as $fil => $ns): ?>
            <span class="badge"><?= h($fil) ?> : <?= number_format(array_sum($ns) / count($ns), 2, ',', ' ') ?></span>
        <?php endforeach; ?>
    </p>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>Photo</th><th>Nom</th><th>Prénom</th><th>Filière</th><th>Note</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php if (empty($etudiants)): ?>
        <tr><td colspan="6" class="vide">Aucun étudiant</td></tr>
    <?php else: ?>
        <?php foreach ($etudiants as $e): ?>
            <tr data-recherche="<?= h(mb_strtolower($e['nom'] . ' ' . $e['prenom'], 'UTF-8')) ?>">
                <td>
                    <?php if ($e['photo'] !== '' && file_exists(DOSSIER_PHOTOS . basename($e['photo']))): ?>
                        <img class="photo" src="uploads/<?= h(basename($e['photo'])) ?>" alt="Photo de <?= h($e['prenom']) ?>">
                    <?php else: ?>
                        <span class="photo sans-photo">?</span>
                    <?php endif; ?>
                </td>
                <td><?= h(nom_affiche($e['nom'])) ?></td>
                <td><?= h(prenom_affiche($e['prenom'])) ?></td>
                <td><?= h($e['filiere']) ?></td>
                <td class="<?= $e['note'] >= 10 ? 'note-ok' : 'note-ko' ?>"><?= number_format($e['note'], 2, ',', ' ') ?></td>
                <td>
                    <a href="ajouter.php?id=<?= (int)$e['id'] ?>">Modifier</a> |
                    <a href="supprimer.php?id=<?= (int)$e['id'] ?>" class="supprimer">Supprimer</a>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php endif; ?>
    </tbody>
</table>

<?php include 'footer.php'; ?>
