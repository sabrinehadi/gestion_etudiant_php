// Confirmation avant suppression
document.querySelectorAll('a.supprimer').forEach(function (lien) {
    lien.addEventListener('click', function (e) {
        if (!confirm('Voulez-vous vraiment supprimer cet étudiant ?')) {
            e.preventDefault();
        }
    });
});

// Recherche instantanée (sans recharger la page)
var champ = document.getElementById('q');
if (champ) {
    champ.addEventListener('input', function () {
        var texte = champ.value.trim().toLowerCase();
        document.querySelectorAll('tbody tr[data-recherche]').forEach(function (ligne) {
            ligne.style.display = ligne.dataset.recherche.indexOf(texte) !== -1 ? '' : 'none';
        });
    });
}
