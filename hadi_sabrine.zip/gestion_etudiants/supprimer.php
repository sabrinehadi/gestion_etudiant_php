<?php
require_once 'functions.php';
exiger_connexion();

$id = (int)($_GET['id'] ?? 0);
$etudiants = lire_etudiants();

if ($id > 0 && isset($etudiants[$id])) {
    supprimer_photo($etudiants[$id]['photo']);
    unset($etudiants[$id]);
    sauver_etudiants($etudiants);
    flash_set('Étudiant supprimé.');
} else {
    flash_set('Étudiant introuvable.', 'erreur');
}

header('Location: liste.php');
exit;
