<?php
// Exercice 3 : test de lecture / écriture (écrase data/etudiants.txt avec 3 étudiants)
require_once 'functions.php';

$liste = [
    1 => ['id' => 1, 'nom' => 'benali', 'prenom' => 'sara', 'filiere' => 'GI', 'note' => 14.5, 'photo' => ''],
    2 => ['id' => 2, 'nom' => 'alaoui', 'prenom' => 'youssef', 'filiere' => 'IDIA', 'note' => 8.25, 'photo' => ''],
    3 => ['id' => 3, 'nom' => 'idrissi', 'prenom' => 'lina', 'filiere' => 'GE', 'note' => 17, 'photo' => ''],
];
sauver_etudiants($liste);

echo '<h3>Contenu du fichier</h3><pre>' . h(file_get_contents(FICHIER)) . '</pre>';
echo '<h3>Relu avec lire_etudiants()</h3><pre>' . h(print_r(lire_etudiants(), true)) . '</pre>';
echo '<p>nettoyer("  Jean;  Paul\n") = "' . h(nettoyer("  Jean;  Paul\n")) . '"</p>';
